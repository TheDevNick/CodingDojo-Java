package main.java;

import main.java.classes.Calculator;

public class App {

	public static void main(String[] args) {
		Calculator calculator = new Calculator();
		calculator.setNum1(5);
		calculator.setNum2(5);
		calculator.setOperator('+');
		calculator.performOpertation();
		calculator.getResult();

	}

}
