
public class ProjectTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Project newProject = new Project("Nick's project", "Java hw project");
//		newProject.setName("Test project");
//		newProject.setDescription("Test description");
		System.out.println(newProject.elevatorPitch());
	}

}
