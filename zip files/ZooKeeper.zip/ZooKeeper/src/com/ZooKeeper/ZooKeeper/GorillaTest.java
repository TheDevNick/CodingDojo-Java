package com.ZooKeeper.ZooKeeper;

public class GorillaTest {

	public static void main(String[] args) {
		Gorilla harambe = new Gorilla();
		harambe.throwSomething();
		harambe.throwSomething();
		harambe.displayEnergy();
		harambe.eatBananas();
		harambe.eatBananas();
		harambe.displayEnergy();

	}

}
