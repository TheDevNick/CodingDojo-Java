package main.java.interfaces;

public interface Ringable {
	String ring();
	String unlock();
}
