package com.codingdojo.test4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test4Application {

	public static void main(String[] args) {
		SpringApplication.run(Test4Application.class, args);
	}

}
